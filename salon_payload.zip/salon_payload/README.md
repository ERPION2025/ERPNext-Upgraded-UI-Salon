# Salon Suite — app payload

This is not a full `bench new-app` output — it's the files that go *inside*
one, so nothing here fights with whatever boilerplate your Frappe v16
bench generates (which differs slightly by version).

## 1. Create the app shell

```bash
bench new-app salon
# module name: Salon
bench --site your-site.com install-app salon
```

## 2. Copy these files in

```
apps/salon/salon/doctype/salon_booking/         <- from salon/doctype/salon_booking/
apps/salon/salon/doctype/booking_service/        <- from salon/doctype/booking_service/
apps/salon/salon/doctype/salon_stylist/          <- from salon/doctype/salon_stylist/
apps/salon/salon/doctype/salon_service_recipe/   <- from salon/doctype/salon_service_recipe/
apps/salon/salon/doctype/recipe_consumable/      <- from salon/doctype/recipe_consumable/
apps/salon/salon/doctype/package_subscription/   <- from salon/doctype/package_subscription/
apps/salon/salon/page/salon_dashboard/           <- from salon/page/salon_dashboard/
apps/salon/salon/api.py                          <- api.py
apps/salon/salon/public/css/salon.css            <- public/css/salon.css
```

Then merge `hooks_additions.py` into the `hooks.py` bench already generated
(don't overwrite it — just add those two lines).

```bash
bench --site your-site.com migrate
bench build --app salon
bench restart
```

## 3. One-time master data (no code, just Desk records)

- **Salary Component** named exactly `Service Commission` (Payroll > Salary
  Component) — the commission automation posts to this.
- A **Salon Stylist** record per Employee, with their `commission_rate` and
  `cost_center` set.
- A **Cost Center** per branch, and a **Warehouse** per branch if you want
  stock deduction working.
- Optional: a **Salon Service Recipe** per service Item, listing the raw
  materials it consumes — only services with a recipe will generate a
  Stock Entry on completion.

## 4. What's a full custom page vs. a link to native Desk

To keep the first pass small, only **Dashboard** (`/app/salon-dashboard`) is
a fully custom page matching the PDF layout — sidebar, KPI cards, live
schedule. The rest of the sidebar links (Bookings, Clients, Packages,
Services, Stylists, Stock, Invoicing) currently point at the native Desk
list view for that doctype, so everything is functional today, just not
re-skinned yet.

Building out one of those into its own custom page (e.g. the Booking
Calendar with drag-to-reschedule, or Client 360) follows the exact same
pattern as `salon_dashboard.js` — a Page record + a JS file rendering into
`page.body` + a whitelisted method in `api.py` feeding it data.

## 5. Matching your exact brandlogin colors

`public/css/salon.css` uses placeholder hex values (`#e4002b` red,
white surfaces) styled to match the PDF. Swap these for the actual
CSS variables/theme tokens your `brandlogin` app already defines, so the
salon suite and the login/module-launcher shell look like one product
instead of two apps that happen to share a color.
