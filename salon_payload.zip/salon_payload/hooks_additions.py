# Add/merge these lines into the hooks.py that `bench new-app salon` already
# generated for you. Don't replace the whole file — it also has app_name,
# app_title, app_publisher etc. that bench fills in from your prompts.

required_apps = ["erpnext"]

app_include_css = "/assets/salon/css/salon.css"
