import frappe
from frappe.utils import today


@frappe.whitelist()
def get_dashboard_kpis(cost_center=None):
	filters = {"booking_datetime": [">=", today()]}
	if cost_center:
		filters["cost_center"] = cost_center

	bookings = frappe.get_all(
		"Salon Booking",
		filters=filters,
		fields=["name", "customer", "salon_stylist", "booking_datetime", "status", "total_amount"],
		order_by="booking_datetime asc",
	)

	conditions = ["b.status = 'Completed'", "date(b.booking_datetime) = %(today)s"]
	values = {"today": today()}
	if cost_center:
		conditions.append("b.cost_center = %(cost_center)s")
		values["cost_center"] = cost_center

	revenue = frappe.db.sql(
		f"""select coalesce(sum(b.total_amount), 0) from `tabSalon Booking` b
		where {' and '.join(conditions)}""",
		values,
	)[0][0]

	commissions = frappe.db.sql(
		"""select coalesce(sum(amount), 0) from `tabAdditional Salary`
		where salary_component = 'Service Commission' and date(payroll_date) = %(today)s""",
		{"today": today()},
	)[0][0]

	return {
		"today_bookings": len(bookings),
		"revenue_today": revenue,
		"commissions_today": commissions,
		"schedule": bookings,
	}


@frappe.whitelist()
def mark_completed(booking):
	doc = frappe.get_doc("Salon Booking", booking)
	doc.status = "Completed"
	doc.save()
	return doc.status
